# fastapply-resumify
## Installation

1. Install Python packages:
   ```bash
   pip install -r requirements.txt
   ```

2. Download the spaCy model:
   ```bash
   python -m spacy download en_core_web_sm
   ```